import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='svardhineedi',
    application_name='slsapi',
    app_uid='sWKlXqH3dJNMLj11Xw',
    org_uid='e18a477d-050a-46bc-9f8f-8b83bcfbb6d9',
    deployment_uid='968209e9-b70a-413c-ab62-d6d30e0cf3d2',
    service_name='slsapi',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'slsapi-dev-get', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('/user.getUser')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
